import argparse

from ..file.card_ids import assign_new_card_ids_to_files as assign_new_card_ids_to_files_
from ..file.clone import clone_board_file as clone_board_file_
from ..file.clone import clone_tree as clone_tree_
from ..file.io import get_board_notebook_and_text_filenames_in


def assign_new_card_ids_to_files(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('files', action="store", nargs='*', help='The file(s) to assign new card ids to.')
    args = parser.parse_args(args)

    board_files, notebook_files, text_files = get_board_notebook_and_text_filenames_in(args.files)
    assign_new_card_ids_to_files_(board_files, notebook_files, text_files)


def clone_board_file(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('src', help='The board file to clone.')
    parser.add_argument('dst', help='The name of the cloned board file.')
    args = parser.parse_args(args)

    clone_board_file_(src=args.src, dst=args.dst)


def clone_tree(args=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('src', help='The root of the directory tree to clone.')
    parser.add_argument('dst', help='The root of the cloned directory tree.')
    parser.add_argument('--symlinks', action='store_true', default=False, help='Copy symbolic links as symbolic links.')
    parser.add_argument('--ignore', action='store', nargs='*', default=None, help='A list of file patterns to ignore.')
    parser.add_argument('--ignore_dangling_symlinks', action='store_true', default=False, help='Ignore dangling symbolic links.')
    args = parser.parse_args(args)

    clone_tree_(src=args.src, dst=args.dst, symlinks=args.symlinks, ignore=args.ignore, ignore_dangling_symlinks=args.ignore_dangling_symlinks)
