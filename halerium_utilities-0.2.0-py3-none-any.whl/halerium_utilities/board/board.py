import uuid
import json

import numpy as np

from ..file.io import read_board, write_board


def is_board(obj):
    return isinstance(obj, dict) and ("nodes" in obj) and ("edges" in obj)


def create_board():
    """Create board.

    Returns
    -------
    board :
        The newly created board.

    """
    board = {
        "nodes": [],
        "edges": []
        }
    return board


def create_card(title=None,
                content=None,
                position=None,
                size=None,
                color=None,
                card_properties=None):
    """Create a card.

    Parameters
    ----------
    title :
        The title of the card.
    content :
        The card content. Either a string, or a list of quill delta operations.
    position :
        The position of the card on the board.
    size :
        The size of the card.
    color :
        The color of the card.
    card_properties :
        A dictionary with additional properties to be added to the card.
        This may override any of the other card properties.

    Returns
    -------
    card :
        The card.

    """
    if title is None:
        title = ""

    if content is None:
        ops = []
    elif isinstance(content, str):
        ops = [{'insert': content}]
    else:
        ops = content

    if position is None:
        position = {'x': 0.0 + np.random.randint(-100, 100),
                    'y': 0.0 + np.random.randint(-100, 100)}

    if size is None:
        size = {'width': 400,
                'height': 400}

    if color is None:
        color = '#125059'

    message = json.dumps({'ops': ops})

    node_id = str(uuid.uuid4())

    card = {
        'id'              : node_id,
        'title'           : title,
        'type_specific'   : {'message': message},
        'edge_connections': [],
        'type'            : 'note',
        'position'        : position,
        'size'            : size,
        'color'           : color,
    }
    if card_properties is not None:
        card.update(card_properties)

    return card


def add_card_to_board(board, card):
    """Add card to board.

    Parameters
    ----------
    board :
        The board or file path or descriptor of the board to add a card to.
    card :
        The card to add.

    Returns
    -------

    """
    if is_board(board):
        board['nodes'].append(card)
    else:
        board_file = board
        board = read_board(board_file)
        board['nodes'].append(card)
        write_board(board, board_file)
